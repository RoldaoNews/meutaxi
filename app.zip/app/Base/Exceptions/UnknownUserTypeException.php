<?php

namespace App\Base\Exceptions;

use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;

class UnknownUserTypeException extends NotFoundHttpException {

}
