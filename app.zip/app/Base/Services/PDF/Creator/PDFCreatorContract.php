<?php

namespace App\Base\Services\PDF\Creator;

interface PDFCreatorContract {
	// [WIP] Add relevant pdf generator/download methods when needed.
}
