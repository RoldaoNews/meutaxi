<?php

namespace App\Base\Constants\Taxi;

class UnitType
{
    const MILES = '2';
    const KILOMETER = '1';
}
