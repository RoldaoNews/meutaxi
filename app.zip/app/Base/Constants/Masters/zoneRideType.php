<?php

namespace App\Base\Constants\Masters;

class zoneRideType
{
    const RIDENOW = 1;
    const RIDELATER = 2;
}
