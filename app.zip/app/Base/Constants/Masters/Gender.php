<?php

namespace App\Base\Constants\Masters;

class Gender {

	const MALE = 1;
	const FEMALE = 2;
	const TRANSGENDER = 3;

}
