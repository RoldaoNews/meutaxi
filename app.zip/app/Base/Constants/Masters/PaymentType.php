<?php

namespace App\Base\Constants\Masters;

class PaymentType
{
    const CARD = 0;
    const CASH = 1;
    const WALLET = 2;
    const WALLET_AND_CASH = 3;
}
