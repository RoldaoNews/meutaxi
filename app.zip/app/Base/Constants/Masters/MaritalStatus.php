<?php

namespace App\Base\Constants\Masters;

class MaritalStatus {

	const SINGLE = 1;
	const MARRIED = 2;
	const WIDOW = 3;
	const WIDOWER = 4;
	const OTHERS = 5;

}
