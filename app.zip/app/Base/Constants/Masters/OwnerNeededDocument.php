<?php

namespace App\Base\Constants\Masters;

class OwnerNeededDocument
{
    const DOCUMENTONE = 'License';
    const DOCUMENTTWO = 'Rc Book';
    const DOCUMENTTHREE = 'Insurance';
    const DOCUMENTFOUR = 'Passport';
    const DOCUMENTFIVE = 'Voter card';
}
