<?php

namespace App\Base\Constants\Queue;

class Queue
{
    const MIEC = 'miec';
    const PRIORITY = 'priority';
}
